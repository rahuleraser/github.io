# Rahul Eraser Portfolio

This is the personal IT portfolio website for Rahul Eraser.

- Technologies: Python, AWS, React, Docker, DevOps
- Projects and experience included!

> Site will be updated soon.